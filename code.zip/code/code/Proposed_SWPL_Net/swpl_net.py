# cloud_load_balancer/swpl_net.py
import numpy as np
import math


class SWPLNetLoadBalancer:
    def __init__(self, optimal_weights):
        self.weights = optimal_weights

    def _atrous_convolution(self, signal, weights, atrous_rate):
        n = len(signal)
        conv_out = 0.0
        w_len = len(weights)
        for i in range(n):
            val = 0.0
            for j in range(w_len):
                idx = i + j * atrous_rate
                if idx < n:
                    val += signal[idx] * weights[j % len(weights)]
            conv_out += val
        return conv_out

    def _compute_load_balancing_parameters(self, vms, tasks):
        lb_vectors = []
        vm_cts = []
        N = len(vms)
        for vm in vms:
            capacity = max(1.0, (vm.cpu * vm.memory * vm.processing_elements * vm.bandwidth) / (1.05 * 10.0))
            load_val = vm.current_load / capacity
            vm_ct = sum([t.length / max(1.0, vm.cpu) for t in vm.tasks]) if vm.tasks else 0.0
            vm_cts.append(vm_ct)
            lb_vectors.append([capacity, load_val, vm_ct])

        makespan = max(vm_cts) if vm_cts else 1.0
        arur = sum(vm_cts) * (1.0 / (max(1, N) * makespan))
        return np.array(lb_vectors, dtype=float), makespan, arur

    def _compute_task_parameters(self, tasks):
        task_features = []
        for t in tasks:
            exec_time = t.length / 500.0
            completion_time = exec_time * t.priority
            response_time = completion_time * 0.8
            task_features.append(
                [float(t.priority), float(t.length), float(exec_time), float(completion_time), float(response_time)])
        return np.array(task_features, dtype=float)

    def balance_load(self, overloaded_vms, underloaded_vms, predicted_resources, tasks, ranked_vms=None):
        """Step 6: Balance load using SwideFH-Net harmonic analysis, integrating VM Significance Ranking[cite: 3, 30]."""
        print("[SWPL-Net] Executing SwideFH-Net Harmonic Analysis model with VM Significance Ranking...")

        # Prioritize overloaded VMs based on VM significance ranking if available
        if ranked_vms:
            significance_order = {vm.vm_id: idx for idx, vm in enumerate(ranked_vms)}
            overloaded_vms = sorted(overloaded_vms, key=lambda v: significance_order.get(v.vm_id, 999))

        all_vms = overloaded_vms + underloaded_vms
        Lb, makespan, arur = self._compute_load_balancing_parameters(all_vms, tasks)
        Tp = self._compute_task_parameters(tasks)

        w1 = self.weights[:min(5, len(self.weights))]
        w2 = float(np.sum(self.weights)) if len(self.weights) > 0 else 1.0
        atrous_rate = 2

        migration_log = []
        t_step = 1.0
        trig_term_1 = (1.0 - math.cos(math.pi * t_step)) / 2.0
        trig_term_2 = (1.0 + math.cos(math.pi * t_step)) / 2.0

        for ovm in overloaded_vms:
            sorted_tasks = sorted(ovm.tasks, key=lambda t: t.priority, reverse=True)

            for task in sorted_tasks:
                if underloaded_vms:
                    best_uvm = min(underloaded_vms, key=lambda u: u.current_load)

                    flat_tp = Tp.flatten()
                    if len(flat_tp) < len(w1):
                        flat_tp = np.pad(flat_tp, (0, len(w1) - len(flat_tp)), 'constant')

                    conv_tp = self._atrous_convolution(flat_tp[:len(w1)], w1, atrous_rate)
                    sum_tp_w1 = np.sum(flat_tp[:len(w1)] * w1)
                    E1 = conv_tp * sum_tp_w1

                    sum_lb = np.sum(Lb) if Lb.size > 0 else 1.0
                    E2 = sum_lb * w2 * E1
                    E3 = (E2 * trig_term_1) + (E1 * trig_term_2)

                    predicted_demand = predicted_resources.get(best_uvm.vm_id, best_uvm.current_load)

                    if abs(E3) >= 0.0 and best_uvm.current_load < predicted_demand:
                        best_uvm.tasks.append(task)
                        best_uvm.current_load += task.req_cpu
                        ovm.current_load -= task.req_cpu
                        ovm.tasks.remove(task)
                        migration_log.append((task.task_id, ovm.vm_id, best_uvm.vm_id))

                    if best_uvm.current_load > ovm.current_load:
                        break

        print(f"[SWPL-Net] Harmonic analysis balancing completed. Migrations: {len(migration_log)}")
        return migration_log