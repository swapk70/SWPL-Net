# cloud_load_balancer/bidlstm.py
import numpy as np

try:
    import torch
    import torch.nn as nn

    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

if TORCH_AVAILABLE:
    class BiDLSTMModel(nn.Module):
        def __init__(self, input_dim=5, hidden_dim=16, output_dim=1):
            super(BiDLSTMModel, self).__init__()
            # Bi-directional LSTM layer
            self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True, bidirectional=True)
            # Fully connected layer mapping bidirectional hidden state (hidden_dim * 2) to output resource demand
            self.fc = nn.Linear(hidden_dim * 2, output_dim)

        def forward(self, x):
            # x shape: (batch_size, seq_len, input_dim)
            out, _ = self.lstm(x)
            # Take the output of the last time step
            out = self.fc(out[:, -1, :])
            return out


class BiDLSTMPredictor:
    def __init__(self):
        self.use_torch = TORCH_AVAILABLE
        if self.use_torch:
            self.model = BiDLSTMModel()
            self.model.eval()  # Evaluation mode for inference simulation

    def predict_resources(self, vms):
        """Step 4: Predict future resource demands ($R_{vm}$) using Bi-DLSTM based on multi-parameter time steps."""
        print("[Bi-DLSTM] Running actual Bi-DLSTM temporal feature prediction for VM resource demands...")
        predictions = {}

        for vm in vms:
            # Feature vector representation {CPU, Memory, Bandwidth, Freq Scaling, Processing Elements} across historical time steps
            # Simulating a short sequence of past time steps (e.g., sequence length = 3)
            seq_len = 3
            historical_features = []
            for t in range(seq_len):
                # Add slight temporal variation to past states
                factor = 1.0 - (seq_len - t) * 0.05
                step_features = [
                    vm.cpu * factor,
                    vm.memory * factor,
                    vm.bandwidth * factor,
                    vm.freq_scaling,
                    vm.processing_elements,
                ]
                historical_features.append(step_features)

            if self.use_torch:
                # Prepare tensor for PyTorch Bi-DLSTM: shape (1, seq_len, input_dim)
                x_tensor = torch.tensor([historical_features], dtype=torch.float32)
                with torch.no_grad():
                    pred_tensor = self.model(x_tensor)
                # Scale output to match realistic load bounds
                predicted_demand = float(pred_tensor.item()) + vm.current_load * 1.05
            else:
                # Fallback mathematical trend projection if torch is missing
                predicted_demand = float(np.mean([f[0] for f in historical_features]) * 0.2 + vm.current_load * 1.1)

            predictions[vm.vm_id] = max(50.0, abs(predicted_demand))

        print(f"[Bi-DLSTM] Predicted Resources ($R_{vm}$): {predictions}")
        return predictions