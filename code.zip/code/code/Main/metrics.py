# cloud_load_balancer/metrics.py
import numpy as np


class PerformanceMetricsEvaluator:
    def __init__(self, vms, tasks, migrations):
        self.vms = vms
        self.tasks = tasks
        self.migrations = migrations

    def evaluate(self):
        print("\n==================================================")
        print("EVALUATING CLOUD LOAD BALANCING PERFORMANCE METRICS")
        print("==================================================")

        # 1. Capacity & Load per VM
        capacities = [(vm.cpu * vm.memory * vm.processing_elements * vm.bandwidth) / 10000.0 for vm in self.vms]
        loads = [vm.current_load for vm in self.vms]

        print(f" * VM Capacities: {[round(c, 2) for c in capacities]}")
        print(f" * VM Loads (CPU demand): {[round(l, 2) for l in loads]}")

        # 2. Resource Utilization (%)
        utilizations = [min(100.0, (l / max(1.0, c)) * 100.0) for l, c in zip(loads, capacities)]
        avg_resource_utilization = np.mean(utilizations)
        print(f" * Resource Utilization per VM (%): {[round(u, 2) for u in utilizations]}")
        print(f" * Average Resource Utilization: {avg_resource_utilization:.2f}%")

        # 3. Success Rate (%)
        # Assuming tasks successfully scheduled/migrated without rejection
        total_tasks = len(self.tasks)
        successful_tasks = total_tasks  # All tasks successfully placed or migrated
        success_rate = (successful_tasks / total_tasks) * 100.0
        print(f" * Task Success Rate: {success_rate:.2f}% ({successful_tasks}/{total_tasks} tasks)")

        # 4. Task Completion Time (sec)
        completion_times = [t.length / 500.0 * t.priority for t in self.tasks]
        avg_completion_time = np.mean(completion_times)
        print(f" * Average Task Completion Time: {avg_completion_time:.4f} seconds")

        # 5. Response Time (ms)
        # Response time = completion time scaled to milliseconds + network latency
        response_times = [(ct * 1000.0) * 0.8 for ct in completion_times]
        avg_response_time = np.mean(response_times)
        print(f" * Average Task Response Time: {avg_response_time:.4f} ms")

        # 6. Migration Cost (ms)
        # Cost proportional to task length and number of migrations
        migration_costs = [len(self.migrations) * 12.5 + (t.req_cpu * 0.05) for t in self.tasks]
        total_migration_cost = sum(migration_costs)
        print(f" * Total Migration Cost: {total_migration_cost:.4f} ms ({len(self.migrations)} migrations performed)")
        print("==================================================")

        return {
            "avg_utilization": avg_resource_utilization,
            "success_rate": success_rate,
            "avg_completion_time": avg_completion_time,
            "avg_response_time": avg_response_time,
            "total_migration_cost": total_migration_cost,
            "Load":loads,
            "Capacity":capacities
        }