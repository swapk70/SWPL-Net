# cloud_load_balancer/simulator.py
import numpy as np


class VM:
    def __init__(self, vm_id, cpu, memory, bandwidth, freq_scaling, processing_elements):
        self.vm_id = vm_id
        self.cpu = cpu  # MHz
        self.memory = memory  # MB
        self.bandwidth = bandwidth  # Mbps
        self.freq_scaling = freq_scaling
        self.processing_elements = processing_elements
        self.current_load = 0.0
        self.tasks = []

    def __repr__(self):
        return f"VM(id={self.vm_id}, Load={self.current_load:.2f}, Tasks={len(self.tasks)})"


class Task:
    def __init__(self, task_id, priority, length, req_cpu, req_memory):
        self.task_id = task_id
        self.priority = priority
        self.length = length
        self.req_cpu = req_cpu
        self.req_memory = req_memory


class CloudSimulator:
    def __init__(self, num_vms=5, num_tasks=20):
        np.random.seed(42)
        self.vms = [
            VM(i, cpu=np.random.randint(2000, 4000),
               memory=np.random.randint(4096, 16384),
               bandwidth=np.random.randint(500, 1000),
               freq_scaling=np.random.uniform(1.0, 2.5),
               processing_elements=np.random.randint(2, 8))
            for i in range(num_vms)
        ]
        self.tasks = [
            Task(i, priority=np.random.randint(1, 5),
                 length=np.random.randint(500, 2000),
                 req_cpu=np.random.randint(200, 800),
                 req_memory=np.random.randint(256, 1024))
            for i in range(num_tasks)
        ]

    def assign_round_robin(self):
        """True Round-Robin Queue Assignment across VMs."""
        print("[Simulator] Executing Round-Robin Task Queue Allocation...")

        # Simulate a cyclic queue distribution mimicking cloud broker behavior
        vm_count = len(self.vms)
        for i, task in enumerate(self.tasks):
            target_vm_index = i % vm_count
            target_vm = self.vms[target_vm_index]

            # Append task to VM's execution queue
            target_vm.tasks.append(task)
            target_vm.current_load += task.req_cpu

        return self.vms, self.tasks