# cloud_load_balancer/Run.py
from simulator import CloudSimulator
from bcfcm import BCFCMCategorizer
from pagerank import VMSignificanceRanker
from bidlstm import BiDLSTMPredictor
from Proposed_SWPL_Net.plemfoa import PlemFOAOptimizer
from Proposed_SWPL_Net.swpl_net import SWPLNetLoadBalancer
from metrics import PerformanceMetricsEvaluator

def Callmain(n_vm,n_tasks):
    LOAD,CAP,RU,SR,RT,TCT,MC=[],[],[],[],[],[],[]
    # Assign the tasks to the VMs in the data center in round robin fashion initially
    sim = CloudSimulator(num_vms=n_vm, num_tasks=n_tasks)
    vms, tasks = sim.assign_round_robin()

    # Based on the VM parameters, like CPU, memory, bandwidth, frequency scaling factor, processing elements, categorize the VMs as overloaded VMs and underloaded VMs using BCFCM
    categorizer = BCFCMCategorizer(vms)
    overloaded_vms, underloaded_vms = categorizer.categorize()
    print(f" -> Overloaded VMs: {[vm.vm_id for vm in overloaded_vms]}")
    print(f" -> Underloaded VMs: {[vm.vm_id for vm in underloaded_vms]}")

    #  VM Significance Ranking
    ranker = VMSignificanceRanker(vms)
    ranked_vms = ranker.rank_vms()

    #  Predict the VM resource request using Bi-DLSTM
    predictor = BiDLSTMPredictor()
    predicted_resources = predictor.predict_resources(vms)

    #  Optimize SWPL-Net using PlemFOA
    optimizer = PlemFOAOptimizer()
    optimal_weights = optimizer.optimize()
    print(f" -> PlemFOA Optimization Completed. Optimal Weights Shape: {optimal_weights.shape}")

    #  Load Balancing using SWPL-Net (Passing ranked_vms to prioritize critical VMs)
    balancer = SWPLNetLoadBalancer(optimal_weights)
    migrations = balancer.balance_load(overloaded_vms, underloaded_vms, predicted_resources, tasks,
                                       ranked_vms=ranked_vms)

    print("==================================================")
    print("LOAD BALANCING MIGRATION RESULTS:")
    for task_id, src_vm, dest_vm in migrations:
        print(f" * Migrated Task {task_id} from Overloaded VM {src_vm} to Underloaded VM {dest_vm}")
    print("==================================================")
    print("SIMULATION COMPLETED SUCCESSFULLY!")
    evaluator = PerformanceMetricsEvaluator(vms, tasks, migrations)
    result=evaluator.evaluate()

    LOAD.append(result['Load'])
    CAP.append(result['Capacity'])
    RU.append(result['avg_utilization'])
    SR.append(result['success_rate'])
    RT.append(result['avg_response_time'])
    TCT.append(result['avg_completion_time'])
    MC.append(result['total_migration_cost'])

    return LOAD,CAP,RU,SR,RT,TCT,MC


