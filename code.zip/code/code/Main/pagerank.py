# cloud_load_balancer/pagerank.py
import numpy as np


class VMSignificanceRanker:
    def __init__(self, vms):
        self.vms = vms

    def rank_vms(self):
        """Step 3: Estimate VM significance ranking using a weighted PageRank algorithm based on VM capacity and load."""
        print("[PageRank] Calculating VM significance ranking using Weighted PageRank...")
        n = len(self.vms)

        # 1. Build a weighted adjacency matrix based on VM parameters (CPU, Memory, Processing Elements)
        # VMs with higher resources and lower current load get higher significance weights.
        adj_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    # Weight based on relative computing capacity and inverse load
                    capacity_i = self.vms[i].cpu * self.vms[i].processing_elements
                    load_j = max(self.vms[j].current_load, 1.0)  # Avoid division by zero

                    # Link weight from VM i to VM j
                    adj_matrix[i, j] = capacity_i / load_j

        # Normalize rows to create the weighted transition probability matrix
        row_sums = adj_matrix.sum(axis=1, keepdims=True)
        # Handle zero rows if any
        row_sums[row_sums == 0] = 1.0
        transition_matrix = adj_matrix / row_sums

        # 2. PageRank power iteration
        pr = np.ones(n) / n
        damping = 0.85
        max_iter = 50
        tolerance = 1e-6

        for _ in range(max_iter):
            pr_new = (1 - damping) / n + damping * np.dot(transition_matrix.T, pr)
            if np.linalg.norm(pr_new - pr) < tolerance:
                break
            pr = pr_new

        # 3. Sort VMs in descending order of their significance values
        ranked_indices = np.argsort(pr)[::-1]
        ranked_vms = [self.vms[i] for i in ranked_indices]

        print(f"[PageRank] VM Significance Ranking (Desc): {[vm.vm_id for vm in ranked_vms]}")
        print(f"[PageRank] Significance Scores: {np.round(pr[ranked_indices], 4)}")

        return ranked_vms