# cloud_load_balancer/bcfcm.py
import numpy as np


class BCFCMCategorizer:
    def __init__(self, vms, m=2.0, max_iter=100, error=1e-5):
        self.vms = vms
        self.m = m  # Fuzziness exponent (typically 2.0)
        self.max_iter = max_iter
        self.error = error

    def categorize(self):
        """Step 2: Categorize VMs into overloaded and underloaded using BCFCM fuzzy clustering."""
        print("[BCFCM] Running actual Bias-Corrected/Balanced Fuzzy C-Means (BCFCM) clustering on VMs...")

        # 1. Extract multi-dimensional feature matrix for VMs: [CPU, Memory, Bandwidth, Freq, PE, Load]
        data = np.array([
            [vm.cpu, vm.memory, vm.bandwidth, vm.freq_scaling, vm.processing_elements, vm.current_load]
            for vm in self.vms
        ], dtype=float)

        n_samples = data.shape[0]
        n_clusters = 2  # Cluster 0: Underloaded, Cluster 1: Overloaded

        if n_samples < n_clusters:
            # Fallback if too few VMs for clustering
            mean_load = np.mean(data[:, 5])
            overloaded = [vm for vm in self.vms if vm.current_load >= mean_load]
            underloaded = [vm for vm in self.vms if vm.current_load < mean_load]
            return overloaded, underloaded

        # 2. Initialize fuzzy membership matrix U randomly (normalized columns/rows)
        np.random.seed(42)
        U = np.random.rand(n_samples, n_clusters)
        U /= np.sum(U, axis=1, keepdims=True)

        cluster_centers = np.zeros((n_clusters, data.shape[1]))

        # 3. FCM Iterative Optimization Loop
        for iteration in range(self.max_iter):
            U_old = U.copy()

            # Calculate fuzzy cluster centers
            um = U ** self.m
            denominator = np.sum(um, axis=0, keepdims=True)
            cluster_centers = np.dot(um.T, data) / np.maximum(denominator.T, 1e-8)

            # Calculate Euclidean distances from data points to cluster centers
            distances = np.linalg.norm(data[:, np.newaxis, :] - cluster_centers[np.newaxis, :, :], axis=2)
            distances = np.maximum(distances, 1e-8)  # Prevent division by zero

            # Update fuzzy membership matrix
            power = 2.0 / (self.m - 1.0)
            inv_distances = (1.0 / distances) ** power
            U = inv_distances / np.sum(inv_distances, axis=1, keepdims=True)

            # Check convergence
            if np.linalg.norm(U - U_old) < self.error:
                break

        # 4. Assign VMs based on maximum membership value
        cluster_assignments = np.argmax(U, axis=1)

        # Determine which cluster represents "overloaded" by checking mean load of the cluster elements
        cluster_loads = []
        for c_idx in range(n_clusters):
            cluster_indices = np.where(cluster_assignments == c_idx)[0]
            if len(cluster_indices) > 0:
                cluster_loads.append(np.mean([self.vms[i].current_load for i in cluster_indices]))
            else:
                cluster_loads.append(0.0)

        overloaded_cluster_idx = int(np.argmax(cluster_loads))

        overloaded_vms = []
        underloaded_vms = []

        for idx, vm in enumerate(self.vms):
            if cluster_assignments[idx] == overloaded_cluster_idx:
                overloaded_vms.append(vm)
            else:
                underloaded_vms.append(vm)

        print(
            f"[BCFCM] Categorization complete. Overloaded VMs: {[vm.vm_id for vm in overloaded_vms]}, Underloaded VMs: {[vm.vm_id for vm in underloaded_vms]}")
        return overloaded_vms, underloaded_vms